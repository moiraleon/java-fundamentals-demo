package com.pluralsight.javaoopfundamentals;

enum ProductType {
    DIGITAL, PHYSICAL;
}
