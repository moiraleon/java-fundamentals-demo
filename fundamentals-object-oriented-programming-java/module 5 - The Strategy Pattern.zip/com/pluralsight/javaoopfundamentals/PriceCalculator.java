package com.pluralsight.javaoopfundamentals;

public interface PriceCalculator {
   public int calculatePrice(int quantity);
}
