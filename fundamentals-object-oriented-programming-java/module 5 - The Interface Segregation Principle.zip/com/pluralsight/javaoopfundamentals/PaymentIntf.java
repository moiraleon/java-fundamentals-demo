package com.pluralsight.javaoopfundamentals;

public interface PaymentIntf {
   public void execute();
   void setValue(int value);
   int getValue();
}
