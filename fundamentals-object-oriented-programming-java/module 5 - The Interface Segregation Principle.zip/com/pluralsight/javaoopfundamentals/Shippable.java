package com.pluralsight.javaoopfundamentals;

public interface Shippable {
   public void ship();
}
