package com.pluralsight.javaoopfundamentals;

public interface Replaceable {
   public void replace();
}
